/*Grupo 05
	Joana Sousa no47084, Joao Leal no46394,
	Liliana Delgadinho no43334*/

#ifndef _PRIMARY_BACKUP_PRIVATE_H
#define _PRIMARY_BACKUP_PRIVATE_H

#include "primary_backup.h"

#endif
